package com.example.new_bbts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
