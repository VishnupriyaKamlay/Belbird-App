import 'dart:async';
import 'package:BBTS/views/qr.dart';
import 'package:open_settings/open_settings.dart';
import 'package:flutter/material.dart';
import '../controller/storage_controller.dart';
import '../model/group.dart';
import '../utils/constants.dart';
import '../widgets/group_card.dart';
import '../widgets/toast.dart';
import 'ConnectToGroup.dart';
import 'gallery_qr.dart';

class GroupingPage extends StatelessWidget {
  GroupingPage({Key? key}) : super(key: key);

  final StorageController _storageController = StorageController();

  // Method to fetch all groups from storage
  Future<List<GroupDetails>> fetchGroups() async {
    return _storageController.readAllGroups();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Stack(
        children: [
          Align(
            alignment: Alignment.bottomCenter,
            child: SizedBox(
              height: 70,
              width: 180,
              child: FloatingActionButton.large(
                onPressed: () {},
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => const QRView(type: "group"),
                        ));
                      },
                      icon: const Icon(Icons.camera_alt_outlined),
                    ),
                    const VerticalDivider(
                      color: Colors.black,
                      thickness: 2,
                      endIndent: 20,
                      indent: 20,
                    ),
                    IconButton(
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => const GalleryQRPage(type: "group"),
                        ));
                      },
                      icon: const Icon(Icons.image_outlined),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomRight,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                FloatingActionButton(
                  onPressed: () {
                    OpenSettings.openWIFISetting();
                  },
                  child: const Icon(Icons.wifi_find),
                  backgroundColor: backGroundColour,
                ),
                const SizedBox(height: 5), // Adjust spacing between buttons
                FloatingActionButton(
                  onPressed: () {
                    OpenSettings.openLocationSourceSetting();
                  },
                  backgroundColor: backGroundColour,
                  child: const Icon(Icons.location_on_rounded),
                ),
              ],
            ),
          ),
        ],
      ),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60),
        child: AppBar(
          iconTheme: IconThemeData(color: appBarColour),
          backgroundColor: backGroundColour,
          automaticallyImplyLeading: false,
          title: Text(
            "GROUPS",
            style: TextStyle(
              color: appBarColour,
              fontSize: 30,
              fontWeight: FontWeight.bold,
            ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 0,
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            FutureBuilder<List<GroupDetails>>(
              future: fetchGroups(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) return const Center(child: Text("ERROR"));
                return ListView.builder(
                  padding: const EdgeInsets.only(top: 10),
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        // Check access type and handle accordingly
                        if (snapshot.data![index].contactsModel.accessType.contains("Timed Access")) {
                          DateTime now = DateTime.now();
                          DateTime startDate = snapshot.data![index].contactsModel.startDateTime;
                          DateTime endDate = snapshot.data![index].contactsModel.endDateTime;
                          print(startDate);
                          print(endDate);
                          if (now.isAfter(endDate)) {
                            showToast(context, "You have surpassed the end date. Contact the admin for fresh approval");
                            return;
                          }
                        }
                        // Navigate to ConnectToGroupWidget
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ConnectToGroupWidget(
                              groupName: snapshot.data![index].groupName,
                              selectedRouter: snapshot.data![index].selectedRouter,
                              selectedSwitches: snapshot.data![index].selectedSwitches,
                            ),
                          ),
                        );
                      },
                      child: GroupCard(groupDetails: snapshot.data![index]),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
