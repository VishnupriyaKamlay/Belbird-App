import 'package:BBTS/model/group.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:scan/scan.dart';
import '../controller/storage_controller.dart';
import '../model/contacts.dart';
import '../model/switches.dart';
import '../model/routers.dart';
import '../utils/constants.dart';
import '../bottom_nav_bar.dart';
import '../widgets/custom_app_bar.dart';
import '../widgets/custom_button.dart';
import '../widgets/toast.dart';

class GalleryQRPage extends StatefulWidget {
  const GalleryQRPage({required this.type, super.key});
  final String type;

  @override
  State<GalleryQRPage> createState() => _GalleryQRPageState();
}

class _GalleryQRPageState extends State<GalleryQRPage> {
  String _platformVersion = 'Unknown';
  final StorageController _storageController = StorageController();

  String _scanBarcode = 'Unknown';

  @override
  void initState() {
    super.initState();
    initPlatformState();
  }

  Future<void> initPlatformState() async {
    String platformVersion;
    try {
      platformVersion = await Scan.platformVersion;
    } on PlatformException {
      platformVersion = 'Failed to get platform version.';
    }
    if (!mounted) return;

    setState(() {
      _platformVersion = platformVersion;
    });
    scanFromGallery();
  }

  scanFromGallery() async {
    XFile? res = (await ImagePicker().pickImage(source: ImageSource.gallery));
    if (res != null) {
      String? str = await Scan.parse(res.path);
      if (str != null) {
        setState(() {
          _scanBarcode  = str;
          print("---------------------");
          print(_scanBarcode );
          print("---------------------");
          parseData(_scanBarcode );
        });
      }
    }
  }

  parseData(barcodeScanRes) {
    try {
      List<String> d = barcodeScanRes.split(",");
      print("Parsed data: $d");
      print("Parsed data length: ${d.length}");

      if (widget.type == "switch") {
        if (d.length != 8) throw Exception("Not correct data for switch. Expected 8 but got ${d.length}");

        ContactsModel contacts = ContactsModel(
          accessType: d[5],
          startDateTime: DateTime.tryParse(d[6])!,
          endDateTime: DateTime.tryParse(d[7])!,
          name: d[4],
        );

        details = SwitchDetails(
          contactsModel: contacts,
          iPAddress: routerIP,
          switchld: d[0],
          isAutoSwitch: false,
          privatePin: "2345",
          switchSSID: d[1],
          switchPassKey: d[2],
          switchPassword: d[3],
        );

      } else if (widget.type == "router") {
        if (d.length != 10) throw Exception("Not correct data for router. Expected 10 but got ${d.length}");

        ContactsModel contacts = ContactsModel(
          accessType: d[7],
          startDateTime: DateTime.tryParse(d[8])!,
          endDateTime: DateTime.tryParse(d[9])!,
          name: d[6],
        );

        routerDetails = RouterDetails(
          switchID: d[0],
          switchName: d[1],
          name: d[2],
          password: d[3],
          switchPasskey: d[4],
          iPAddress: d[5],
          contactsModel: contacts,
        );
      }
      else if (widget.type == "group") {
        // Preprocess the data to remove square brackets
        String preprocessedData = barcodeScanRes.replaceAll(RegExp(r'[\[\]]'), '');
        List<String> d = preprocessedData.split(",");

        // Extract group name and selected router
        String groupName = d[0];
        String selectedRouter = d[1];
        List<RouterDetails> selectedSwitches = [];

        // Extract ContactsModel for the group
        ContactsModel groupContacts = ContactsModel(
          name: d[d.length - 4],
          accessType: d[d.length - 3],
          startDateTime: DateTime.tryParse(d[d.length - 2])!,
          endDateTime: DateTime.tryParse(d[d.length - 1])!,
        );

        // Parse multiple RouterDetails
        for (int i = 2; i < d.length - 4; i += 6) {
          RouterDetails routerDetails = RouterDetails(
            switchID: d[i],
            switchName: d[i + 1],
            name: d[i + 2],
            password: d[i + 3],
            switchPasskey: d[i + 4],
            iPAddress: d[i + 5],
            contactsModel: groupContacts,
          );
          selectedSwitches.add(routerDetails);
          //_storageController.addRouters(routerDetails);
        }

        // Create GroupDetails object
        groupDetails = GroupDetails(
          groupName: groupName,
          selectedRouter: selectedRouter,
          selectedSwitches: selectedSwitches,
          contactsModel: groupContacts,
        );
      }
      else {
        print("Unknown type");
      }
    } catch (e) {
      print(e);
      setState(() {
        _scanBarcode  = "The QR does not have the right data";
      });
    }
  }

  SwitchDetails? details;
  RouterDetails? routerDetails;
  GroupDetails? groupDetails;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Column(children: [
          Text(_scanBarcode),
          CustomButton(
              text: "Submit",
              onPressed: () {
                print(_scanBarcode);
                if (_scanBarcode == "Unknown") {
                  showToast(context, "QR data is not correct.");
                  return;
                }
                if (widget.type == "switch") {
                  _storageController.addswitches(context, details!);
                } else if (widget.type == "router"){
                  _storageController.addRouters(routerDetails!);
                }else if (widget.type == "group"){
                  _storageController.saveGroupDetails(groupDetails!);
                }
                Navigator.pushAndRemoveUntil<dynamic>(
                  context,
                  MaterialPageRoute<dynamic>(
                    builder: (BuildContext context) => const MyNavigationBar(),
                  ),
                      (route) => false, //if you want to disable back feature set to false
                );
              })
        ]),
      ),
    );
  }
}