import '../controller/storage_controller.dart';
import '../model/contacts.dart';
import '../model/group.dart';
import '../model/routers.dart';
import '../model/switches.dart';
import '../utils/constants.dart';
import '../widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import '../bottom_nav_bar.dart';
import '../widgets/toast.dart';

class QRView extends StatefulWidget {
  const QRView({required this.type, super.key});
  final String type;

  @override
  State<QRView> createState() => _QRViewState();
}

class _QRViewState extends State<QRView> {
  SwitchDetails? details;
  RouterDetails? routerDetails;
  GroupDetails? groupDetails;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    scanQR();
  }

  String _scanBarcode = 'Unknown';
  final StorageController _storageController = StorageController();
  // SwitchDetails details = SwitchDetails(
  //     switchld: "Unknown",
  //     switchSSID: "Unknown",
  //     switchPassword: "Unknown",
  //     isAutoSwitch: false,
  //     privatePin: "1234",
  //     iPAddress: "Unknown");
  Future<void> scanQR() async {
    String barcodeScanRes;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
          '#ff6666', 'Cancel', true, ScanMode.QR);
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) return;

    setState(() {
      print("=================");
      _scanBarcode = barcodeScanRes;
      print("Scanned barcode data: $barcodeScanRes");

      try {
        List<String> d = barcodeScanRes.split(",");
        print("Parsed data: $d");
        print("Parsed data length: ${d.length}");

        if (widget.type == "switch") {
          if (d.length != 8) throw Exception("Not correct data for switch. Expected 8 but got ${d.length}");

          ContactsModel contacts = ContactsModel(
            accessType: d[5],
            startDateTime: DateTime.tryParse(d[6])!,
            endDateTime: DateTime.tryParse(d[7])!,
            name: d[4],
          );

          details = SwitchDetails(
            contactsModel: contacts,
            iPAddress: routerIP,
            switchld: d[0],
            isAutoSwitch: false,
            privatePin: "2345",
            switchSSID: d[1],
            switchPassKey: d[2],
            switchPassword: d[3],
          );

        } else if (widget.type == "router") {
          if (d.length != 10) throw Exception("Not correct data for router. Expected 10 but got ${d.length}");

          ContactsModel contacts = ContactsModel(
            accessType: d[7],
            startDateTime: DateTime.tryParse(d[8])!,
            endDateTime: DateTime.tryParse(d[9])!,
            name: d[6],
          );

          routerDetails = RouterDetails(
            switchID: d[0],
            switchName: d[1],
            name: d[2],
            password: d[3],
            switchPasskey: d[4],
            iPAddress: d[5],
            contactsModel: contacts,
          );
        }
        else if (widget.type == "group") {
          // Preprocess the data to remove square brackets
          String preprocessedData = barcodeScanRes.replaceAll(RegExp(r'[\[\]]'), '');
          List<String> d = preprocessedData.split(",");

          // Extract group name and selected router
          String groupName = d[0];
          String selectedRouter = d[1];
          List<RouterDetails> selectedSwitches = [];

          // Extract ContactsModel for the group
          ContactsModel groupContacts = ContactsModel(
            name: d[d.length - 4],
            accessType: d[d.length - 3],
            startDateTime: DateTime.tryParse(d[d.length - 2])!,
            endDateTime: DateTime.tryParse(d[d.length - 1])!,
          );

          // Parse multiple RouterDetails
          for (int i = 2; i < d.length - 4; i += 6) {
            RouterDetails routerDetails = RouterDetails(
              switchID: d[i],
              switchName: d[i + 1],
              name: d[i + 2],
              password: d[i + 3],
              switchPasskey: d[i + 4],
              iPAddress: d[i + 5],
              contactsModel: groupContacts,
            );
            //_storageController.addRouters(routerDetails);
            selectedSwitches.add(routerDetails);
          }

          // Create GroupDetails object
          groupDetails = GroupDetails(
            groupName: groupName,
            selectedRouter: selectedRouter,
            selectedSwitches: selectedSwitches,
            contactsModel: groupContacts,
          );
        }
        else {
          print("Unknown type");
        }

      } catch (e) {
        print(e);
        setState(() {
          _scanBarcode = "The QR does not have the right data: ${e.toString()}";
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Column(children: [
          Text(_scanBarcode),
          CustomButton(
              text: "Submit",
              onPressed: () {
                print(_scanBarcode);
                if (_scanBarcode == "Unknown") {
                  showToast(context, "QR data is not correct.");
                  return;
                }
                if (widget.type == "switch") {
                  _storageController.addswitches(context, details!);
                } else if (widget.type == "router"){
                  _storageController.addRouters(routerDetails!);
                }else if (widget.type == "group"){
                  _storageController.saveGroupDetails(groupDetails!);
                }
                Navigator.pushAndRemoveUntil<dynamic>(
                  context,
                  MaterialPageRoute<dynamic>(
                    builder: (BuildContext context) => const MyNavigationBar(),
                  ),
                  (route) => false, //if you want to disable back feature set to false
                );
              })
        ]),
      ),
    );
  }
}
