package com.example.new_switch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
