import '../widgets/toast.dart';
import 'package:flutter/material.dart';
import '../controllers/storage.dart';
import '../models/contacts.dart';
import '../models/switch_initial.dart';
import '../models/router_model.dart';
import '../widgets/custom_appbar.dart';
import '../widgets/qr.dart';
import '../models/group.dart';

class ShareQRPage extends StatefulWidget {
  final SwitchDetails? switchDetails;
  final RouterDetails? routerDetails;
  final GroupDetails? groupDetails;

  ShareQRPage({super.key, this.switchDetails, this.routerDetails, this.groupDetails});

  @override
  State<ShareQRPage> createState() => _ShareQRPageState();
}

class _ShareQRPageState extends State<ShareQRPage> {
  StorageController _storageController = StorageController();

  List<ContactsModel> contacts = [];

  getData() async {
    contacts = await _storageController.readContacts();
    return (contacts,);
  }

  ContactsModel contact = ContactsModel(
      accessType: "default",
      endDateTime: DateTime.now(),
      startDateTime: DateTime.now(),
      name: "default");

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        child: CustomAppBar(heading: "Share QR"),
        preferredSize: const Size.fromHeight(60),
      ),
      body: Center(
        child: FutureBuilder(
          future: getData(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            }
            print((snapshot.data.runtimeType));
            var x = snapshot.data as (List<ContactsModel>,);
            contacts = x.$1;
            return Column(
              children: [
                const SizedBox(
                  height: 30,
                ),
                const Text("Select Contact"),
                DropdownMenu(
                  onSelected: (value) async {
                    contact = await _storageController.getContactByPhone(value);
                  },
                  dropdownMenuEntries: contacts
                      .map((e) => DropdownMenuEntry(value: e.name, label: e.name))
                      .toList(),
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        if (contact.accessType.contains("default")) {
                          showToast(context, "No contact is selected");
                          return;
                        }
                        String qrData;
                        if (widget.switchDetails != null) {
                          qrData = "${widget.switchDetails!.toSwitchQR()},${contact.toContactsQR()}";
                        } else if (widget.routerDetails != null) {
                          qrData = "${widget.routerDetails!.toRouterQR()},${contact.toContactsQR()}";
                        } else if (widget.groupDetails != null) {
                          qrData = "${widget.groupDetails!.toGroupQR()},${contact.toContactsQR()}";
                        } else {
                          showToast(context, "No details available to share");
                          return;
                        }
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => QRPage(data: qrData),
                          ),
                        );
                      },
                      child: Text("Share"),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text("Cancel"),
                    ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
