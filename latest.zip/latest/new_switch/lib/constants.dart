import 'package:flutter/material.dart';

String routerIP = "http://192.168.6.6";
Color whiteColour = const Color(0xFFFFFFFF);
Color blackColour = const Color(0xFF000000);
Color backGroundColour = const Color(0xff4c4b39ef);
// Colors.deepPurple;
// Color(0xFF4C4B39EF)
Color backGroundColourDark = const Color(0xffee6e43bd);
Color appBarColour = const Color(0xff2902d096a);
Color redColour = Colors.red.shade200;
Color redButtonColour = Colors.red.shade800;
Color greenColour = Colors.green.shade200;
Color greenButtonColour = Colors.green.shade800;
